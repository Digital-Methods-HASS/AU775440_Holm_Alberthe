# HomicideHistory

In this assignment you get to explore and visualise the rates of homicide in Western Europe and compare them with the trends in the duration of reign among Danish (and other) monarchs.

Clone this repository, view the html and work in the rmarkdown file. You will find the tasks in the steps of the document (Danish kings included). 

Submit both a rendered .html and a .Rmd file by uploading to Brightspace or by pushing to *your* github repository and directing your peer-reviewers there by submitting a URL to Brightspace.
